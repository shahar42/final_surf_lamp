wave height strip bottom led - 2  top led - 16
wind speed strip bottom led - 38  top led - 21
wave period strip bottom led - 41 top led - 55
arduino id = 6
total leds = 56
