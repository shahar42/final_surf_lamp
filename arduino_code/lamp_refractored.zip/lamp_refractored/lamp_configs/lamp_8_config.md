wave height strip bottom led - 5  top led - 27
wind speed strip bottom led - 59  top led - 34
wave period strip bottom led - 64 top led - 87
arduino id = 8
