wave led strip bottom - 12  end - 49
wind strip led bottom -  100  top - 59
wave periodd strip bottom - 108  top - 145
